﻿using System;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3_Group7
{
    public class SLL : LinkedListADT
    {
        private Node head;
        private Node tail;



        public Node Head { get => head; set => head = value; }
        public Node Tail { get => tail; set => tail = value; }


        public SLL()
        {
            head = tail = null;
        }

        public void Append(object data)
        {
            if (!IsEmpty())
            {
                tail.Next = new Node(data);
                tail = tail.Next;
            }
            else
            {
                head = tail = new Node(data);
            }

        }

        public void Clear()
        {
            head = tail = null;
        }


        public bool Contains(object data)
        {
            Node current = head;

            while (current != null)
            {
                if (current.Element.Equals(data))
                {
                    return true;
                }
                current = current.Next;
            }

            return false;
        }

        public void Delete(int index)
        {
            if (Size() < index)
            {
                throw new IndexOutOfRangeException();
            }
            else
            {
                /*Node tempNode = head;
				for (int i = 0; i < index - 1; i++)
				{
					tempNode = tempNode.Next;
				}
				Node del = tempNode.Next, aft = del.Next;
				tempNode.Next = aft;*/

                Node target = head;

                for (int k = 1; k < index; k++)
                {
                    target = target.Next;
                }

                Node del = target.Next;
                Node aft = del.Next;

                target.Next = aft; // bypass del

            }
        }

        public int IndexOf(object data)
        {

            Node target;
            if (!IsEmpty())                 //checks if Node is NOT Empty
            {
                int i = 0;
                for (Node tempNode = head; tempNode != null; tempNode = tempNode.Next)
                {
                    if (tempNode.Element.Equals(data))
                    {
                        target = tempNode;
                        break;
                    }
                    i++;

                }
                return i;
            }
            else
            {
                throw new IndexOutOfRangeException();
            }

        }

        public void Insert(object data, int index)
        {
            if (!IsEmpty())                  //checks if Node is NOT Empty
            {
                if ((Size() > index - 1) && index >= 0)
                {
                    Node target = head;
                    if (index == 0)
                    {
                        Prepend(data);
                    }
                    else
                    {
                        for (int k = 1; k <= index - 1; k++)
                        {
                            if (target.Next != null)
                            {
                                target = target.Next;
                            }
                        }
                        Node aft = target.Next;
                        Node vtx = new Node(data);

                        vtx.Next = aft;
                        target.Next = vtx;
                    }
                }
                else
                {
                    throw new IndexOutOfRangeException();
                }
            }
            else
            {
                throw new IndexOutOfRangeException();
            }
        }

        public bool IsEmpty()
        {
            return (head == null) && (tail == null);
        }

        public void Prepend(object data)
        {

            head = new Node(data, head);
            if (tail == null)
            {
                tail = head;
            }
        }

        public void Replace(object data, int index)
        {
            if (IsEmpty())
            {
                throw new IndexOutOfRangeException();
            }

            Node target = head;

            for (int k = 0; k < index; k++)
            {
                if (target == null)
                {
                    throw new IndexOutOfRangeException();
                }
                target = target.Next;
            }

            if (target == null)
            {
                throw new IndexOutOfRangeException();
            }

            target.Element = data;
        }

        public object Retrieve(int index)
        {
            if (!IsEmpty())                  //checks if Node is NOT Empty
            {
                if ((Size() > index - 1) && index >= 0)
                {
                    Node target = head;
                    if (index == 0)
                    {
                        return target.Element.ToString();
                    }
                    else
                    {
                        for (int k = 1; k < index; k++)
                        {
                            target = target.Next;
                        }
                        Node ret = target.Next;
                        //Node aft = ret.Next;

                        //target.Next = aft; // bypass del

                        return ret.Element.ToString();
                    }
                }
                else
                {
                    throw new IndexOutOfRangeException();
                }
            }
            else
            {
                return null;
            }
        }

        public int Size()
        {
            int i = 0;
            for (Node tempNode = head; tempNode != null; tempNode = tempNode.Next)
            {
                i++;
            }
            return i;
        }

    }
}