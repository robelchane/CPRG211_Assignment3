﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3_Group7
{
	public class Node
	{
		private object element;
		private Node succesor;

		public object Element { get => element; set => element = value; }
		public Node Next { get => succesor; set => succesor = value; }
        public object Data { get; internal set; }

        public Node(object o)
		{
			this.Element = o;
		}
		public Node(object o, Node n)
		{
			this.Element = o;
			this.succesor = n;
		}
	}
}
